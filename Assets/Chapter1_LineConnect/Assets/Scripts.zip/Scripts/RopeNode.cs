using UnityEngine;

public class RopeNode : MonoBehaviour
{
    public CircleDot dot;
    public InnerSnapNode innerNode;
}
