
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelTimer : MonoBehaviour
{
    [Header("UI")]
    public Image fillImage;   // drag Fill image here

    float timeLeft;
    float totalTime;
    bool running = false;

    // =========================
    // ▶ START TIMER
    // =========================
    public void StartTimer(float seconds)
    {
        totalTime = seconds;
        timeLeft = seconds;
        running = true;

        if (fillImage != null)
            fillImage.fillAmount = 1f;
    }

    // =========================
    // ⏸ STOP TIMER
    // =========================
    public void StopTimer()
    {
        running = false;
    }

    void Update()
    {
        if (!running) return;

        timeLeft -= Time.deltaTime;

        if (fillImage != null)
            fillImage.fillAmount = timeLeft / totalTime;

        if (timeLeft <= 0f)
        {
            running = false;
            SceneManager.LoadScene("GameOverScene");
        }
    }
}
