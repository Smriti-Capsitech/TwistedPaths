using UnityEngine;

public class InnerSnapNode : MonoBehaviour
{
    public bool isOccupied ;
}
