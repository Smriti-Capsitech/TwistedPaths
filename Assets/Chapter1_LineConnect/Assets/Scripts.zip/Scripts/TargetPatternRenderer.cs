
// using UnityEngine;
// using System.Collections;
// using System.Collections.Generic;

// [RequireComponent(typeof(LineRenderer))]
// public class TargetPatternRenderer : MonoBehaviour
// {
//     [Header("Generators")]
//     public TargetDotGenerator outer;
//     public TargetInnerDotGenerator inner; // still here, not used for star

//     [Header("Pattern (OUTER DOT INDICES ONLY)")]
//     public int[] pattern;

//     LineRenderer line;

//     void Awake()
//     {
//         line = GetComponent<LineRenderer>();
//         line.useWorldSpace = true;
//         line.positionCount = 0;
//     }

//     void Start()
//     {
//         StartCoroutine(WaitAndDraw());
//     }

//     IEnumerator WaitAndDraw()
//     {
//         yield return new WaitUntil(() =>
//             outer != null &&
//             outer.dots != null &&
//             outer.dots.Count > 0
//         );

//         DrawPattern();
//     }

//     void DrawPattern()
//     {
//         if (pattern == null || pattern.Length < 2)
//         {
//             Debug.LogError("TargetPatternRenderer: Pattern too small");
//             return;
//         }

//         foreach (int i in pattern)
//         {
//             if (i < 0 || i >= outer.dots.Count)
//             {
//                 Debug.LogError(
//                     $"TargetPatternRenderer: Invalid OUTER index {i}, max = {outer.dots.Count - 1}"
//                 );
//                 return;
//             }
//         }

//         line.positionCount = pattern.Length;

//         for (int i = 0; i < pattern.Length; i++)
//         {
//             line.SetPosition(i, outer.dots[pattern[i]].position);
//         }
//         Debug.Log($"Target pattern drawn. Count = {line.positionCount}");

//     }

//     // ✅ THIS WAS MISSING — NOW ADDED
//     public int PatternCount => line.positionCount;

//     public Vector3 GetPoint(int i)
//     {
//         return line.GetPosition(i);
//     }
// }
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent(typeof(LineRenderer))]
public class TargetPatternRenderer : MonoBehaviour
{
    [Header("Generators")]
    public TargetDotGenerator outer;
    public TargetInnerDotGenerator inner;

    [Header("Pattern (OUTER DOT INDICES ONLY)")]
    public int[] pattern;

    LineRenderer line;

    void Awake()
    {
        line = GetComponent<LineRenderer>();
        line.useWorldSpace = true;
        line.positionCount = 0;
    }

    void Start()
    {
        Redraw(); // ✅ safe start
    }

    // 🔁 SAFE PUBLIC REDRAW
    public void Redraw()
    {
        if (!gameObject.activeInHierarchy)
            gameObject.SetActive(true);

        StopAllCoroutines();
        StartCoroutine(WaitAndDraw());
    }

    IEnumerator WaitAndDraw()
    {
        yield return new WaitUntil(() =>
            outer != null &&
            outer.dots != null &&
            outer.dots.Count > 0
        );

        DrawPattern();
    }

    void DrawPattern()
    {
        if (pattern == null || pattern.Length < 2)
        {
            Debug.LogError("TargetPatternRenderer: Pattern too small");
            return;
        }

        foreach (int i in pattern)
        {
            if (i < 0 || i >= outer.dots.Count)
            {
                Debug.LogError($"Invalid OUTER index {i}");
                return;
            }
        }

        line.positionCount = pattern.Length;

        for (int i = 0; i < pattern.Length; i++)
            line.SetPosition(i, outer.dots[pattern[i]].position);

        Debug.Log($"Target pattern drawn. Count = {line.positionCount}");
    }

    public int PatternCount => line.positionCount;
    public Vector3 GetPoint(int i) => line.GetPosition(i);
}
