
// using UnityEngine;
// using System.Collections.Generic;
// using System.Linq;

// public class LevelCompleteChecker : MonoBehaviour
// {
//     [Header("References")]
//     public CircularLineController player;
//     public TargetPatternRenderer target;
//     public CircularDotGenerator outerDots;
//     public GameObject levelCompleteUI;

//     [Header("Settings")]
//     public float snapTolerance = 0.35f;

//     bool completed = false;

//     void Start()
//     {
//         if (levelCompleteUI != null)
//             levelCompleteUI.SetActive(false);
//     }

//     // 🔥 Called from EndDrag()
//     public void CheckNow()
//     {
//         if (completed) return;
//         if (player == null || target == null || outerDots == null) return;

//         List<int> playerSeq = NormalizeClosedLoop(GetPlayerOuterSequence());
//         List<int> targetSeq = NormalizeClosedLoop(new List<int>(target.pattern));

//         Debug.Log($"PlayerSeq = {string.Join(",", playerSeq)}");
//         Debug.Log($"TargetSeq = {string.Join(",", targetSeq)}");

//         if (IsSameCycle(playerSeq, targetSeq))
//         {
//             CompleteLevel();
//         }
//         else
//         {
//             Debug.Log("❌ Pattern not matched");
//         }
//     }

//     // =========================
//     // PLAYER → OUTER DOT SEQ
//     // =========================
//     List<int> GetPlayerOuterSequence()
//     {
//         List<int> result = new();

//         for (int i = 0; i < player.LineCount; i++)
//         {
//             int idx = FindNearestOuterDot(player.GetPoint(i));
//             if (idx != -1)
//                 result.Add(idx);
//         }

//         return result;
//     }

//     // =========================
//     // NORMALIZE LOOP
//     // =========================
//     List<int> NormalizeClosedLoop(List<int> seq)
//     {
//         if (seq.Count < 2)
//             return seq;

//         // remove consecutive duplicates
//         for (int i = seq.Count - 1; i > 0; i--)
//         {
//             if (seq[i] == seq[i - 1])
//                 seq.RemoveAt(i);
//         }

//         // remove closing duplicate
//         if (seq.Count > 1 && seq[0] == seq[^1])
//             seq.RemoveAt(seq.Count - 1);

//         return seq;
//     }

//     // =========================
//     // ROTATION + REVERSE CHECK
//     // =========================
//     bool IsSameCycle(List<int> a, List<int> b)
//     {
//         if (a.Count != b.Count)
//             return false;

//         if (IsRotation(a, b))
//             return true;

//         b.Reverse();
//         return IsRotation(a, b);
//     }

//     bool IsRotation(List<int> a, List<int> b)
//     {
//         int n = a.Count;

//         for (int offset = 0; offset < n; offset++)
//         {
//             bool match = true;
//             for (int i = 0; i < n; i++)
//             {
//                 if (a[i] != b[(i + offset) % n])
//                 {
//                     match = false;
//                     break;
//                 }
//             }
//             if (match)
//                 return true;
//         }
//         return false;
//     }

//     // =========================
//     // FIND NEAREST OUTER DOT
//     // =========================
//     int FindNearestOuterDot(Vector3 pos)
//     {
//         float min = snapTolerance;
//         int index = -1;

//         for (int i = 0; i < outerDots.dots.Count; i++)
//         {
//             float d = Vector2.Distance(pos, outerDots.dots[i].transform.position);
//             if (d < min)
//             {
//                 min = d;
//                 index = i;
//             }
//         }

//         return index;
//     }

//     // =========================
//     // COMPLETE
//     // // =========================
//     // void CompleteLevel()
//     // {
//     //     completed = true;

//     //     if (levelCompleteUI != null)
//     //         levelCompleteUI.SetActive(true);

//     //     Debug.Log("🎉 LEVEL COMPLETE 🎉");
//     // }
//     void CompleteLevel()
// {
//     completed = true;

//     if (levelCompleteUI != null)
//         levelCompleteUI.SetActive(true);

//     Debug.Log("🎉 LEVEL COMPLETE 🎉");

//     Invoke(nameof(GoNext), 1.5f);
// }
// public void HideUI()
// {
//     completed = false;

//     if (levelCompleteUI != null)
//         levelCompleteUI.SetActive(false);
// }


// void GoNext()
// {
//     HideUI();  
//     LevelManager.Instance.NextLevel();
// }

// }
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class LevelCompleteChecker : MonoBehaviour
{
    public CircularLineController player;
    public TargetPatternRenderer target;
    public CircularDotGenerator outerDots;
    public LevelTimer timer;

    bool completed = false;

    public void CheckNow()
    {
        if (completed) return;

        List<int> playerSeq = Normalize(GetSeq());
        List<int> targetSeq = Normalize(new List<int>(target.pattern));

        if (IsSameCycle(playerSeq, targetSeq))
            CompleteLevel();
    }

    void CompleteLevel()
    {
        completed = true;
        timer.StopTimer(); // ✅ STOP TIMER
        SceneManager.LoadScene("LevelCompleteScene");
    }

    public void HideUI()
    {
        completed = false;
    }

    // ---------------- HELPER LOGIC (UNCHANGED)
    List<int> GetSeq()
    {
        List<int> r = new();
        for (int i = 0; i < player.LineCount; i++)
        {
            int idx = FindNearest(player.GetPoint(i));
            if (idx != -1) r.Add(idx);
        }
        return r;
    }

    List<int> Normalize(List<int> s)
    {
        for (int i = s.Count - 1; i > 0; i--)
            if (s[i] == s[i - 1]) s.RemoveAt(i);

        if (s.Count > 1 && s[0] == s[^1]) s.RemoveAt(s.Count - 1);
        return s;
    }

    bool IsSameCycle(List<int> a, List<int> b)
    {
        if (a.Count != b.Count) return false;
        return IsRotation(a, b) || IsRotation(a, Reverse(b));
    }

    bool IsRotation(List<int> a, List<int> b)
    {
        for (int o = 0; o < a.Count; o++)
        {
            bool ok = true;
            for (int i = 0; i < a.Count; i++)
                if (a[i] != b[(i + o) % b.Count]) { ok = false; break; }
            if (ok) return true;
        }
        return false;
    }

    List<int> Reverse(List<int> l) { l.Reverse(); return l; }

    int FindNearest(Vector3 p)
    {
        float min = 0.35f;
        int idx = -1;
        for (int i = 0; i < outerDots.dots.Count; i++)
        {
            float d = Vector2.Distance(p, outerDots.dots[i].transform.position);
            if (d < min) { min = d; idx = i; }
        }
        return idx;
    }
}
