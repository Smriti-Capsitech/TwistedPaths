using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelCompleteButtons : MonoBehaviour
{
    // ▶ NEXT LEVEL BUTTON
    public void NextLevel()
    {
        // If LevelManager exists (same scene, no scene switch)
        if (LevelManager.Instance != null)
        {
            LevelManager.Instance.NextLevel();
        }
        else
        {
            // ✅ We are in LevelCompleteScene
            // Increase saved level index
            int currentLevel = PlayerPrefs.GetInt("CURRENT_LEVEL", 0);
            PlayerPrefs.SetInt("CURRENT_LEVEL", currentLevel + 1);

            // Load gameplay scene
            SceneManager.LoadScene("SampleScene");
        }
    }

    // 🏠 MAIN MENU BUTTON
    public void MainMenu()
    {
        // Reset progress when going to menu
        PlayerPrefs.DeleteKey("CURRENT_LEVEL");
        SceneManager.LoadScene("ChapterSelectScene");
    }
}
