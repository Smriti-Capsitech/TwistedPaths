using UnityEngine;
using System.Collections.Generic;

public class InnerGridGenerator : MonoBehaviour
{
    [Header("Prefab")]
    public GameObject innerNodePrefab;   // InnerSnapNode prefab

    [Header("Board Reference")]
    public SpriteRenderer board;

    [Header("Settings")]
    public float innerRadiusMultiplier = 0.1f;

    public List<InnerSnapNode> nodes = new();

    void Start()
    {
        GenerateInnerGrid();
    }

    void GenerateInnerGrid()
    {
        nodes.Clear();

        float boardRadius = board.bounds.size.x * 0.5f;
        float innerRadius = boardRadius * innerRadiusMultiplier;

        // ======================
        // INNER 4 NODES
        // ======================
        for (int i = 0; i < 4; i++)
        {
            float angle = i * Mathf.PI * 2f / 4f;

            Vector3 pos = new Vector3(
                Mathf.Cos(angle),
                Mathf.Sin(angle),
                0
            ) * innerRadius;

            CreateNode(pos);
        }

        // ======================
        // CENTER NODE (1)
        // ======================
        CreateNode(Vector3.zero);
    }

    void CreateNode(Vector3 localPos)
    {
        GameObject obj = Instantiate(innerNodePrefab, transform);
        obj.transform.localPosition = localPos;

        InnerSnapNode node = obj.GetComponent<InnerSnapNode>();
        nodes.Add(node);
    }
}
