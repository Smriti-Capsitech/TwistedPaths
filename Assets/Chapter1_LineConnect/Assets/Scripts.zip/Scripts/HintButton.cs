// using UnityEngine;
// using System.Collections;

// public class HintButton : MonoBehaviour
// {
//     [Header("References")]
//     public LevelManager levelManager;
//     public CircularDotGenerator outerDots;

//     [Header("Visual")]
//     public Color hintColor = Color.cyan;
//     public float hintDuration = 2f;

//     bool hintUsed = false;

//     // 🔵 BUTTON ONCLICK
//     public void ShowHint()
//     {
//         if (hintUsed) return;
//         if (levelManager == null || outerDots == null) return;

//         LevelData level = levelManager.GetCurrentLevel();
//         if (level.hintDots == null || level.hintDots.Length == 0)
//             return;

//         StartCoroutine(FlashDots(level.hintDots));
//         hintUsed = true;
//     }

//     IEnumerator FlashDots(int[] indices)
//     {
//         SpriteRenderer[] renderers = new SpriteRenderer[indices.Length];
//         Color[] original = new Color[indices.Length];

//         // APPLY HINT COLOR
//         for (int i = 0; i < indices.Length; i++)
//         {
//             int idx = indices[i];
//             if (idx < 0 || idx >= outerDots.dots.Count)
//                 continue;

//             SpriteRenderer sr = outerDots.dots[idx].GetComponent<SpriteRenderer>();
//             if (sr == null) continue;

//             renderers[i] = sr;
//             original[i] = sr.color;
//             sr.color = hintColor;
//         }

//         yield return new WaitForSeconds(hintDuration);

//         // RESTORE COLOR
//         for (int i = 0; i < renderers.Length; i++)
//         {
//             if (renderers[i] != null)
//                 renderers[i].color = original[i];
//         }
//     }

//     // 🔁 CALL THIS ON NEW LEVEL
//     public void ResetHint()
//     {
//         hintUsed = false;
//     }
// }
using UnityEngine;
using System.Collections;

public class HintButton : MonoBehaviour
{
    [Header("References")]
    public LevelManager levelManager;
    public CircularDotGenerator outerDots;

    [Header("Visual")]
    public Color hintColor = Color.cyan;
    public float hintDuration = 2f;

    bool hintUsed = false;
    bool isShowing = false;

    // =========================
    // 💡 SHOW HINT
    // =========================
    public void ShowHint()
    {
        if (hintUsed || isShowing) return;
        if (levelManager == null || outerDots == null) return;

        LevelData level = levelManager.GetCurrentLevel();
        if (level.hintDots == null || level.hintDots.Length == 0)
            return;

        StartCoroutine(FlashDots(level.hintDots));
        hintUsed = true;
    }

    IEnumerator FlashDots(int[] indices)
    {
        isShowing = true;

        SpriteRenderer[] renderers = new SpriteRenderer[indices.Length];
        Color[] original = new Color[indices.Length];

        for (int i = 0; i < indices.Length; i++)
        {
            int idx = indices[i];
            if (idx < 0 || idx >= outerDots.dots.Count)
                continue;

            SpriteRenderer sr = outerDots.dots[idx].GetComponent<SpriteRenderer>();
            if (sr == null) continue;

            renderers[i] = sr;
            original[i] = sr.color;
            sr.color = hintColor;
        }

        yield return new WaitForSeconds(hintDuration);

        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] != null)
                renderers[i].color = original[i];
        }

        isShowing = false;
    }

    // =========================
    // 🔁 RESET HINT STATE
    // =========================
    public void ResetHints()
    {
        hintUsed = false;
        isShowing = false;
    }

    // =========================
    // 🔁 REPLAY CURRENT LEVEL
    // =========================
    public void ReplayLevel()
    {
        if (levelManager == null)
        {
            Debug.LogError("❌ LevelManager missing in HintButton");
            return;
        }

        Debug.Log("🔁 Replay current level");

        ResetHints();
        levelManager.ReplayCurrentLevel();
    }
}
